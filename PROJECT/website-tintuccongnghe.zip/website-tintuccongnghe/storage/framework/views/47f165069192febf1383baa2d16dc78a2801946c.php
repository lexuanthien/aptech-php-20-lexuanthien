<?php $__env->startSection('phannoidung'); ?>
            <!--PHẦN NỘI DUNG-->

              <h1>Create Category - Tạo Một Thể Loại Mới</h1>
              <hr>
              <form action="<?php echo e(route('categories.store')); ?>" method="POST">
                  <input type="hidden" name="_token" value=<?php echo e(csrf_token()); ?>>
      
                  <div class="form-group">
                    <label for="">Categories Name:</label>
                    <input type="text" class="form-control" name="category_name" placeholder="Categories Name">
                  </div>
                  <div class="mt-2">
                    <button type="submit" class="btn btn-success font-weight-bold">THÊM</button>
                  </div>
              </form>    
          </div>

          <!--HẾT PHẦN NỘI DUNG-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>