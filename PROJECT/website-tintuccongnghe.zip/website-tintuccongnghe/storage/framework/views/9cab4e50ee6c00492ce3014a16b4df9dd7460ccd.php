<?php $__env->startSection('phannoidung'); ?>
    <!-- BẮT ĐẦU PHẦN NỘI DUNG -->
      <h1>Users Page - Trang Người Dùng</h1>
      <hr>
      <div class="mx-4">
        <form action="<?php echo e(route('users.create')); ?>" method="GET">
            <button type="submit" class="btn btn-info rounded-0 font-weight-bold">THÊM CHỨC NĂNG MỚI CHO USER</button>
        </form>  
      </div>
      <div class="mx-4">
      <table class="table table-bordered mt-3">
        <thead>
        <tr class="text-center text-danger">
                <?php
                    $PostArray = ['ID','NAME','EMAIL', 'PASSWORD', 'VAI TRÒ','EDIT', 'XÓA'];
                    for($i=0 ; $i < count($PostArray); $i++) {
                        echo "<th>" . $PostArray[$i] . "</th>";
                    }
                ?>
            </tr>
        </thead>

        <tbody class="text-center text-dark ">
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user->id); ?></td>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->password); ?></td>
                    <td><?php echo e($user->role->name); ?></td>
                    <td> 
                      <form action="<?php echo e(route('users.edit', $user->id)); ?>" method="GET">
                        <button type="submit" class="btn btn-warning mx-2">EDIT</button>
                      </form>
                    </td>
                    <td class="">
                    <form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="POST">
                            <input type="hidden" name="_method" value="DELETE">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <button type="submit" class="btn btn-danger">DELETE</button>
                        </form>
                    </td>
                <tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    </div>
    </div>
    </div>
    <!-- HẾT PHẦN NỘI DUNG -->

<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>