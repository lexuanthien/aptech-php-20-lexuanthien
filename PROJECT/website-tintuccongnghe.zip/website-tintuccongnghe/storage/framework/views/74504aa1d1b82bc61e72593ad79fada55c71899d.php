<?php $__env->startSection('phannoidung'); ?>
          <!--PHẦN NỘI DUNG-->
          <h1>Show Page - Hiển Thị Chi Tiết Bài Viết</h1>
          <hr>
      
          <div class="mx-4">
          <table class="table table-bordered mt-3">
            <thead>
            <tr class="text-center text-danger">
                <?php
                    $PostArray = ['ID','TITLE','DESCRIPTION','CONTENT','THỂ LOẠI','TIN HOT','IMAGE','SLUG','EDIT','DELETE', 'HOME'];
                    for($i=0 ; $i < count($PostArray); $i++) {
                        echo "<th>" . $PostArray[$i] . "</th>";
                    }
                ?>
            </tr>
            </thead>

            <tbody class="text-center text-dark ">
             
                <tr>
                    <td><?php echo e($posts->id); ?></td>
                    <td><?php echo e($posts->title); ?></td>
                    <td><?php echo e($posts->description); ?></td>
                    <td><?php echo e($posts->content); ?></td>
                    <td><?php echo e($posts->category->name); ?></td>
                    <td>
                      <?php if($posts->tin_hot == 1): ?> <?php echo e('TIN BÌNH THƯỜNG'); ?>

                      <?php else: ?> <?php echo e('TIN HOT'); ?>

                      <?php endif; ?>
                    </td>
                    <td><?php echo e($posts->image); ?>

                        <img src="<?php echo e(asset('uploads/posts/' . $posts->image)); ?>" width="100px;" height="100px;">
                    </td>
                    <td><?php echo e($posts->slug); ?></td>
                    <td>
                        <form action="<?php echo e(route('posts.edit', $posts->id)); ?>" method="GET">
                            <button type="submit" class="btn btn-warning mx-2">EDIT</button>
                        </form>
                    </td>
                    <td>    
                        <form action="<?php echo e(route('posts.destroy', $posts->id)); ?>" method="POST">
                            <input type="hidden" name="_method" value="DELETE">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <button type="submit" class="btn btn-danger">DELETE</button>
                        </form>
                    </td>
                    <td>
                      <form action="<?php echo e(route('posts.index', $posts->id)); ?>" method="GET">
                            <button type="submit" class="btn btn-info mx-2">HOME</button>
                      </form>
                    </td>
                    
                <tr>
             
            </tbody>
          </table>
          </div>
          </div>
          <!--HẾT PHẦN NỘI DUNG-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>