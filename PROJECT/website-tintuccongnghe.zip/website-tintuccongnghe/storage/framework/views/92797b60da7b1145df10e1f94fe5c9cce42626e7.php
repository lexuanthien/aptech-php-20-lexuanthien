<?php $__env->startSection('phannoidung'); ?>
            <!--PHẦN NỘI DUNG-->

              <h1>Create User - TẠO NGƯỜI DÙNG MỚI</h1>
              <hr>
              <form action="<?php echo e(route('users.store')); ?>" method="POST">
                  <input type="hidden" name="_token" value=<?php echo e(csrf_token()); ?>>
      
                  <div class="form-group">
                    <label for=""> Username:</label>
                    <input type="text" class="form-control" name="name" placeholder="Username">
                  </div>
                  <div class="form-group">
                    <label for=""> Email:</label>
                    <input type="email" class="form-control" name="email" placeholder="Email">
                  </div>
                  <div class="form-group">
                    <label for=""> Password:</label>
                    <input type="password" class="form-control" name="password" placeholder="Password">
                  </div>
                  <div class="form-group">
                    <label for=""> Vai Trò: </label>
                    <select name="role_id">
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($role->id); ?>">
                            <?php echo e($role->name); ?> 
                          </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                  <div class="mt-2">
                    <button type="submit" class="btn btn-success font-weight-bold">TẠO</button>
                  </div>
              </form>    
          </div>

          <!--HẾT PHẦN NỘI DUNG-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>