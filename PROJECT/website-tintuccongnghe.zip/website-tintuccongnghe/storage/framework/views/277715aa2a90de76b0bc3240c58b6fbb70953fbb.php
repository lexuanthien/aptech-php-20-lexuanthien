<?php $__env->startSection('phannoidung'); ?>
    <!-- BẮT ĐẦU PHẦN NỘI DUNG -->
      <h1>List Page - Trang Bài Viết</h1>
      <hr>
      <div class="mx-4">
        <form action="<?php echo e(route('posts.create')); ?>" method="GET">
            <button type="submit" class="btn btn-info rounded-0 font-weight-bold">TẠO BÀI VIẾT MỚI</button>
        </form>  
      </div>
      <div class="mx-4">
      <table class="table table-bordered mt-3">
        <thead>
        <tr class="text-center text-danger">
                <?php
                    $PostArray = ['ID','TITLE','DESCRIPTION','THỂ LOẠI','TIN HOT','IMAGE','XEM','SỬA','XÓA'];
                    for($i=0 ; $i < count($PostArray); $i++) {
                        echo "<th>" . $PostArray[$i] . "</th>";
                    }
                ?>
            </tr>
        </thead>

        <tbody class="text-center text-dark ">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($post->id); ?></td>
                    <td><?php echo e($post->title); ?></td>
                    <td><?php echo e($post->description); ?></td>
                    <td><?php echo e($post->category->name); ?></td>
                    <td>
                      <?php if($post->tin_hot == 1): ?> <?php echo e('TIN BÌNH THƯỜNG'); ?>

                      <?php else: ?> <?php echo e('TIN HOT'); ?>

                      <?php endif; ?>
                    </td>
                    <td>
                        <img src="<?php echo e(asset('uploads/posts/' . $post->image)); ?>" width="100px;" height="100px;">
                    </td>
                    <td>
                        <form action="<?php echo e(route('posts.show', $post->id)); ?>" method="GET">
                            <button type="submit" class="btn btn-success">SHOW</button>
                        </form>
                    </td>
                    <td>    
                        <form action="<?php echo e(route('posts.edit', $post->id)); ?>" method="GET">
                            <button type="submit" class="btn btn-warning mx-2">EDIT</button>
                        </form>
                    </td>
                    <td>    
                        <form action="<?php echo e(route('posts.destroy', $post->id)); ?>" method="POST">
                            <input type="hidden" name="_method" value="DELETE">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <button type="submit" class="btn btn-danger">DELETE</button>
                        </form>
                    </td>
                <tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    </div>
    </div>
    </div>
    <!-- HẾT PHẦN NỘI DUNG -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>