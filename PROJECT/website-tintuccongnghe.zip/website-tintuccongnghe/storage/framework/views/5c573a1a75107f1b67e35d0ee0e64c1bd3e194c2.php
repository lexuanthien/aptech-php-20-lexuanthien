<?php $__env->startSection('phannoidung'); ?>
          <!--PHẦN NỘI DUNG-->
              <h1>Edit Category - Chỉnh Sửa Thông Tin Thể Loại</h1>
              <hr>
              <form action="<?php echo e(route('categories.update', $category->id)); ?>" method="POST">
                <input type="hidden" name="_method" value="PUT">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <div class="form-group">
                  <label>Category:</label>
                  <input type="text" class="form-control" name="name_category" value="<?php echo e($category->name); ?>">
                </div>
                <div class="mt-2">
                  <button type="submit" class="btn btn-warning font-weight-bold">LƯU</button>
                </div>
              </form>
          </div>

          <!--HẾT PHẦN NỘI DUNG-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>