<?php $__env->startSection('phannoidung'); ?>
          <!--PHẦN NỘI DUNG-->
              <h1>Edit User - Chỉnh Sửa Thông Tin Người Dùng</h1>
              <hr>
              <form action="<?php echo e(route('users.update', $user->id)); ?>" method="POST">
                <input type="hidden" name="_method" value="PUT">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <div class="form-group">
                  <label>Username:</label>
                  <input type="text" class="form-control" name="name" value="<?php echo e($user->name); ?>">
                </div>
                <div class="form-group">
                  <label>Email:</label>
                  <input type="text" class="form-control" name="email" value="<?php echo e($user->email); ?>">
                </div>
                <div class="form-group">
                  <label>Password:</label>
                  <input type="text" class="form-control" name="password" value="<?php echo e($user->password); ?>">
                </div>
                <div class="form-group">
                    <label for=""> Vai Trò: </label>
                    <select name="tenvaitro">
                        <?php $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roles): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($roles->id); ?>">
                            <?php echo e($roles->name); ?> 
                          </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="mt-2">
                  <button type="submit" class="btn btn-warning font-weight-bold">LƯU</button>
                </div>
              </form>
  <!--HẾT PHẦN NỘI DUNG-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>