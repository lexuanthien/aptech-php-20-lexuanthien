    
    <nav id="logoNavbar1" class="navbar navbar-expand-md sticky-top">
        <div class="container-fluid">
            
            <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
                <img id="hinhlogo" src="<?php echo e(asset('websitenews/image/inews.png')); ?>">
            </a>
            <button class="navbar-toggler navbar-dark" type="button" data-toggle="collapse" data-target="#navbarSupportedContent">
                    <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul id="listNavbar1" class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link active d-none d-md-block" href="<?php echo e(route('trangchu')); ?>"><i class="fas fa-home fa-lg"></i></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active d-none d-md-block" href="<?php echo e(route('moinhat')); ?>">MỚI NHẤT</a>
                    </li>
                      
                    <?php $__currentLoopData = $categories->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('news', $category->slug)); ?>"><?php echo e($category->name); ?></a>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                </ul>
                
                <form action=" <?php echo e(route('timkiem')); ?>" method="get" id="search">
                  <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    <div class="search-box">
                    <input class="search-txt" type="search" name="timkiem" placeholder="Search...">
                    <button type="submit" class="search-btn"><i class="fa fa-search" aria-hidden="true"></i></button>
                    <!-- <a class="search-btn" href="" type="submit" name="timkiem" >
                      <i class="fa fa-search" aria-hidden="true"></i>
                    </a> -->
                    </div>
                </form>


                <li class="nav-item dropdown">
                  <a class="nav-link dropdown-toggle" href="<?php echo e(route('login')); ?>" id="navbardrop" data-toggle="dropdown">
                    <i class="fas fa-user-circle fa-lg mt-1"></i>
                  </a>
                  <?php if(auth()->guard()->guest()): ?>
                  <div class="dropdown-content">
                    <a class="dropdown-item" href="<?php echo e(route('login')); ?>" alt="Login"><i class="fas fa-sign-in-alt"></i></a>
                    <a class="dropdown-item" href="<?php echo e(route('register')); ?>"><i class="fas fa-user-edit"></i></a>
                  </div>
                  <?php else: ?>
                  <div class="dropdown-content">
                    <a href="#" data-toggle="tooltip" data-placement="left" title=" Username - <?php echo e(Auth::user()->name); ?> !"><i class="fas fa-id-card"></i></a> 
                    <!-- tooltip để hiển thị thông tin khi chỉ chuột vào -->
                    <a class="dropdown-item" href="<?php echo e(route('dangxuat')); ?>"><i class="fas fa-sign-out-alt"></i></a>
                  </div>
                  <?php endif; ?>
                </li>
                            
                
    
            </div>
        </div>
    </nav>

    <!--HẾT PHẦN LOGO + MENU-->    
    
    <!--PHẦN MENU 2-->
    <!-- <div class="container-fluid" style="background-color:  rgb(91, 121, 43);">
      <div class="container">
        <div class="row">
        <div class="d-none d-sm-block col-sm-12 col-md-8 ">
            <nav class="navbar navbar-expand-sm">
              <ul id="listNavbar2" class="navbar-nav mr-auto"> 
                        <li class="nav-item">
                        <a class="nav-link" href="#">CỘNG ĐỒNG</a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-link" href="#">KHÁM PHÁ</a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-link" href="#">LIÊN HỆ</a>
                        </li>
                      <?php if(auth()->guard()->guest()): ?>
                          <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('login')); ?>">LOGIN</a>
                          </li>
                          <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('register')); ?>">REGISTER</a>
                          </li>
                      <?php else: ?>  
                          <li class="nav-item ">
                            <a class="nav-link" href=""><?php echo e(Auth::user()->name); ?></a>
                          </li>
                          <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('dangxuat')); ?>">ĐĂNG XUẤT</a>
                          </li>
                      <?php endif; ?>
                </ul>
            </nav>

          </div>
          <div class="col-6 d-none d-md-block col-md-4">
              <nav class="navbar navbar-expand-sm navbar-dark justify-content-end">
                <ul id="listNavbar3" class="navbar-nav">
                        <li class="nav-item">
                        <a class="nav-link"><?php echo e($time->toDateString()); ?></a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-link" href="#"><i class="fab fa-facebook-f"></i><a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-link" href="#"><i class="fab fa-youtube"></i><a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-link" href="#"><i class="fab fa-twitter"></i></a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-link" href="#"><i class="fas fa-envelope"></i><a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-link" href="#"><i class="fab fa-google-plus-g"></i><a>
                        </li>
                </ul>
              </nav>
          </div>
      </div>
      </div>
    </div> -->

<script>
$(document).ready(function(){
  $('[data-toggle="tooltip"]').tooltip();   
});
</script>

<script>

window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 80 || document.documentElement.scrollTop > 80) {
    document.getElementById("hinhlogo").style.width = "35px";
  } else {
    document.getElementById("hinhlogo").style.width = "50px";
  }
}
</script>