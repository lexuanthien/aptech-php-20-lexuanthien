<?php $__env->startSection('phannoidung'); ?>
          <!--PHẦN NỘI DUNG-->
              <h1>Edit Comment - Chỉnh Sửa Bình Luận</h1>
              <hr>
              <form action="<?php echo e(route('comments.update', $comments->id)); ?>" method="POST">
                <input type="hidden" name="_method" value="PUT">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <div class="form-group">
                  <label>NỘI DUNG BÌNH LUÂN:</label>
                  <input type="text" class="form-control" name="comment" value="<?php echo e($comments->content_comment); ?>">
                </div>
                <div class="mt-2">
                  <button type="submit" class="btn btn-warning font-weight-bold">LƯU</button>
                </div>
              </form>
  <!--HẾT PHẦN NỘI DUNG-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>